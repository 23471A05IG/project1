import React from 'react';
import { Package, Users, Megaphone, Calendar, MapPin, Clock, ArrowRight } from 'lucide-react';

const ServicesPage = () => {
  const services = [
    {
      icon: Package,
      title: 'Food Collection Drives',
      description: 'Organized collection events at schools, offices, and community centers to gather non-perishable food items.',
      features: [
        'Monthly community collection events',
        'Corporate partnership programs',
        'School-based food drives',
        'Holiday special collections'
      ],
      color: 'emerald'
    },
    {
      icon: Users,
      title: 'Volunteer Coordination',
      description: 'Connecting passionate volunteers with meaningful opportunities to serve their communities.',
      features: [
        'Volunteer training programs',
        'Flexible scheduling options',
        'Team building activities',
        'Recognition and rewards system'
      ],
      color: 'blue'
    },
    {
      icon: Megaphone,
      title: 'Awareness Programs',
      description: 'Educational initiatives to raise awareness about food insecurity and promote community involvement.',
      features: [
        'Community workshops',
        'Social media campaigns',
        'Educational presentations',
        'Resource distribution'
      ],
      color: 'purple'
    }
  ];

  const upcomingEvents = [
    {
      title: 'Community Food Drive',
      date: 'March 15, 2025',
      time: '9:00 AM - 3:00 PM',
      location: 'Central Community Center',
      description: 'Join us for our monthly food collection drive.'
    },
    {
      title: 'Volunteer Training',
      date: 'March 22, 2025',
      time: '10:00 AM - 12:00 PM',
      location: 'FoodShare Office',
      description: 'Learn about food safety and distribution protocols.'
    },
    {
      title: 'Awareness Workshop',
      date: 'March 28, 2025',
      time: '2:00 PM - 4:00 PM',
      location: 'Lincoln High School',
      description: 'Educational session about food insecurity in our community.'
    }
  ];

  return (
    <div className="py-12">
      {/* Header Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6">
            Our{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Services
            </span>
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Comprehensive programs designed to combat food insecurity and build stronger, 
            more connected communities through collective action.
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            const colorClasses = {
              emerald: 'from-emerald-500 to-emerald-600 bg-emerald-50 text-emerald-600',
              blue: 'from-blue-500 to-blue-600 bg-blue-50 text-blue-600',
              purple: 'from-purple-500 to-purple-600 bg-purple-50 text-purple-600'
            };

            return (
              <div key={index} className="bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
                <div className={`bg-gradient-to-br ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[0]} ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[1]} p-4 rounded-2xl mb-6 w-fit`}>
                  <IconComponent className="h-10 w-10 text-white" />
                </div>
                
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[0]} ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[1]}`}></div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={`w-full bg-gradient-to-r ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[0]} ${colorClasses[service.color as keyof typeof colorClasses].split(' ')[1]} text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 flex items-center justify-center space-x-2`}>
                  <span>Learn More</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="bg-white py-16 rounded-3xl mx-4 shadow-xl mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Upcoming Events
            </h2>
            <p className="text-gray-600 text-lg">
              Join us at our upcoming community events and make a direct impact
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="group">
                <div className="bg-gradient-to-br from-emerald-50 to-blue-50 p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform group-hover:-translate-y-1 border border-emerald-100">
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{event.title}</h3>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center space-x-3 text-gray-600">
                      <Calendar className="h-5 w-5 text-emerald-600" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-600">
                      <Clock className="h-5 w-5 text-blue-600" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-600">
                      <MapPin className="h-5 w-5 text-purple-600" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 leading-relaxed">{event.description}</p>
                  
                  <button className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:shadow-md transition-all duration-200">
                    Register Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-1 rounded-3xl">
          <div className="bg-white rounded-3xl p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Ready to Get Involved?
            </h2>
            <p className="text-gray-600 text-lg mb-6 leading-relaxed">
              Whether you want to donate, volunteer, or organize an event, we're here to help 
              you make a meaningful impact in your community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200">
                Contact Us
              </button>
              <button className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200">
                Volunteer Today
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;