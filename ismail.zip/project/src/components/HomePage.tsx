import React from 'react';
import { Heart, Users, Package, ArrowRight, Sparkles } from 'lucide-react';

const HomePage = () => {
  return (
    <div className="py-12">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-br from-emerald-500 to-blue-600 p-4 rounded-2xl shadow-lg">
              <Heart className="h-12 w-12 text-white" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6 leading-tight">
            Welcome to{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              FoodShare
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Join our mission to combat hunger and food insecurity in our communities. 
            Every donation matters, every meal counts, and every act of kindness creates lasting change.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200 flex items-center space-x-2">
              <span>Start Donating</span>
              <ArrowRight className="h-5 w-5" />
            </button>
            
            <button className="bg-white text-emerald-600 border-2 border-emerald-600 px-8 py-4 rounded-xl font-semibold hover:bg-emerald-50 transition-all duration-200">
              Learn More
            </button>
          </div>
        </div>
      </section>

      {/* Impact Statistics */}
      <section className="bg-white py-16 rounded-3xl mx-4 shadow-xl mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Our Impact Together
            </h2>
            <p className="text-gray-600 text-lg">
              See how your contributions are making a real difference
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="bg-gradient-to-br from-emerald-100 to-emerald-50 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-200">
                <Package className="h-12 w-12 text-emerald-600 mx-auto" />
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-2">50,000+</h3>
              <p className="text-gray-600 font-medium">Meals Distributed</p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-200">
                <Users className="h-12 w-12 text-blue-600 mx-auto" />
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-2">12,500+</h3>
              <p className="text-gray-600 font-medium">People Helped</p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gradient-to-br from-purple-100 to-purple-50 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-200">
                <Sparkles className="h-12 w-12 text-purple-600 mx-auto" />
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-2">850+</h3>
              <p className="text-gray-600 font-medium">Active Volunteers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-1 rounded-3xl">
          <div className="bg-white rounded-3xl p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Together, We Can End Hunger
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              Our food drive initiative connects generous donors with families and individuals 
              facing food insecurity. Through organized collection drives, community partnerships, 
              and volunteer efforts, we ensure that nutritious meals reach those who need them most.
            </p>
            <div className="mt-6 flex justify-center">
              <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-3 rounded-full">
                <Heart className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;