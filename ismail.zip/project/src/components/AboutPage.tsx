import React from 'react';
import { Heart, Shield, Users, Truck, CheckCircle, Globe } from 'lucide-react';

const AboutPage = () => {
  const importancePoints = [
    {
      icon: Shield,
      title: 'Food Safety First',
      description: 'Proper donation practices ensure food safety and prevent health risks for vulnerable populations.',
      color: 'emerald'
    },
    {
      icon: Heart,
      title: 'Nutritional Value',
      description: 'Quality donations provide essential nutrients that support healthy development and well-being.',
      color: 'blue'
    },
    {
      icon: Users,
      title: 'Dignity & Respect',
      description: 'Thoughtful donations preserve the dignity of recipients and show genuine care for their welfare.',
      color: 'purple'
    },
    {
      icon: Truck,
      title: 'Efficient Distribution',
      description: 'Proper packaging and labeling help our volunteers distribute food quickly and effectively.',
      color: 'orange'
    }
  ];

  const guidelines = [
    'Non-perishable items with at least 6 months before expiration',
    'Canned goods without dents, rust, or damage',
    'Unopened packages in original containers',
    'Items that provide balanced nutrition (proteins, grains, vegetables)',
    'Baby formula and food with current dates',
    'Personal hygiene items and household essentials'
  ];

  return (
    <div className="py-12">
      {/* Header Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6">
            About Our{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Mission
            </span>
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Understanding the critical importance of proper food donations and how they 
            create lasting impact in the lives of those facing food insecurity.
          </p>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="bg-white py-16 rounded-3xl mx-4 shadow-xl mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">
                Why Food Donations Matter
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-6">
                Food insecurity affects millions of people worldwide, including families, children, 
                seniors, and individuals facing temporary hardships. When we donate food properly 
                and thoughtfully, we're not just providing meals – we're offering hope, dignity, 
                and the foundation for a better tomorrow.
              </p>
              <div className="flex items-center space-x-3 text-emerald-600">
                <Globe className="h-6 w-6" />
                <span className="font-semibold">Making a global impact, one community at a time</span>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-emerald-500 to-blue-600 p-8 rounded-3xl shadow-2xl transform rotate-3">
                <div className="bg-white p-6 rounded-2xl transform -rotate-6">
                  <div className="text-center">
                    <Heart className="h-16 w-16 text-emerald-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">1 in 9</h3>
                    <p className="text-gray-600">People worldwide face chronic hunger</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Importance Points */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            The Importance of Proper Donations
          </h2>
          <p className="text-gray-600 text-lg">
            Every aspect of food donation matters – from safety to nutrition to respect
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {importancePoints.map((point, index) => {
            const IconComponent = point.icon;
            const colorClasses = {
              emerald: 'from-emerald-500 to-emerald-600 text-emerald-600 bg-emerald-50',
              blue: 'from-blue-500 to-blue-600 text-blue-600 bg-blue-50',
              purple: 'from-purple-500 to-purple-600 text-purple-600 bg-purple-50',
              orange: 'from-orange-500 to-orange-600 text-orange-600 bg-orange-50'
            };

            return (
              <div key={index} className="group">
                <div className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 h-full">
                  <div className={`bg-gradient-to-br ${colorClasses[point.color as keyof typeof colorClasses].split(' ')[0]} ${colorClasses[point.color as keyof typeof colorClasses].split(' ')[1]} p-4 rounded-xl mb-4 w-fit`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{point.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{point.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Donation Guidelines */}
      <section className="bg-gradient-to-br from-emerald-50 to-blue-50 py-16 rounded-3xl mx-4 mb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Donation Guidelines
            </h2>
            <p className="text-gray-600 text-lg">
              Help us help others by following these important donation guidelines
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-xl">
            <div className="grid gap-4">
              {guidelines.map((guideline, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                  <CheckCircle className="h-6 w-6 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 leading-relaxed">{guideline}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-1 rounded-3xl">
          <div className="bg-white rounded-3xl p-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Ready to Make a Difference?
            </h2>
            <p className="text-gray-600 text-lg mb-6 leading-relaxed">
              Your thoughtful donations can transform lives and strengthen our community. 
              Together, we can ensure that no one goes hungry.
            </p>
            <button className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200">
              Get Involved Today
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;